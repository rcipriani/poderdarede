import {Component, OnInit} from '@angular/core';
import { Router,
        RouteConfig,
        ROUTER_DIRECTIVES,
        RouteParams } from '@angular/router-deprecated';
import {Observable} from 'rxjs/Observable';

// Pages
import {HomePage} from './pages/home/home.page';
import {PagePage} from './pages/page/page.page';
import {NoticiaPage} from './pages/noticia/noticia.page';
import {BuscaPage} from './pages/busca/busca.page';

// Components
import {ExternalUrlPageComponent} from './components/external-url-page/external-url-page.component';

// Services
import {PageService} from './pages/page/page.service';
import {NoticiaService} from './pages/noticia/noticia.service';
import {UsuarioService} from './services/usuario/usuario.service';

//Models
import {Page} from './pages/page/page.class';
import {Noticia} from './pages/noticia/noticia.class';
import {Usuario} from './services/usuario/usuario.class';

@Component({
    selector: 'portal',
    templateUrl: './app/portal.template.html',
    styleUrls: ['./app/portal.style.css'],
    directives: [ROUTER_DIRECTIVES]
})

@RouteConfig([
    {
        path: '/',
        name: 'Home',
        component: HomePage,
        useAsDefault: true
    },
    {
        path: '/busca',
        name: 'Busca',
        component: BuscaPage
    },
    {
        path: '/page/:slug',
        name: 'Page',
        component: PagePage
    },
    {
        path: '/noticia/:slug',
        name: 'Noticia',
        component: NoticiaPage
    },
    {
        path: '/out/:slug',
        name: 'Out',
        component: ExternalUrlPageComponent
    }
])

export class PortalComponent implements OnInit {

    pages: Observable<Page[]>;
    usuarioAtivo: Usuario;
    isHome: boolean = false;

    constructor(
        private _pageService: PageService,
        private _usuarioService: UsuarioService,
        private _router: Router) {

    }

    ngOnInit() {
        
        this._usuarioService.usuario$.subscribe(data => {
            this.usuarioAtivo = data;
        });
        this._usuarioService.loadUsuarioLogado();

        this._router.subscribe((url) => {

            this._router.recognize(url).then((instruction) => {

                this.isHome = instruction.component.componentType.name == "HomePage";

            });

        });

        // TODO Corrigir para pegar somente o titulo e id, não precisa trazer o restante
        this.pages = this._pageService.pages$;
        this._pageService.loadPages(false);

    }

    ngAfterViewInit() {

        $(function() {
            // Fixa navbar ao ultrapassa-lo
            // Deposi alterar esta para diminuir a logo e a altura da barra
            var navbar = $('.navbar_primary'), distance = navbar.offset().top, $window = $(window);

            $window.scroll(function() {
                if ($window.scrollTop() >= distance) {
                    navbar.removeClass('navbar-fixed-top').addClass('navbar-fixed-top');
//                    $(".novo-portal-usi").css("padding-top", "70px");
                    navbar.css("box-shadow", "0 0 30px black");
                } else {
                    navbar.removeClass('navbar-fixed-top');
//                    $(".novo-portal-usi").css("padding-top", "0px");
                    navbar.css("box-shadow", "0 0 0px black");
                }
            });

        });
        
//        $(function() {
//            console.log("Iniciou!!!!!!!!!!!!");
//            $(".checkbox-switch").bootstrapSwitch();
//
//        });

    }
    
    logout(){
        this._usuarioService.logout();    
    }

    abrirUrl(url) {
        window.open(url, '_blank');
    }

}
