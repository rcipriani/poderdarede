import {bootstrap}    from '@angular/platform-browser-dynamic';
import {ROUTER_PROVIDERS} from '@angular/router-deprecated';
import {HTTP_PROVIDERS, BrowserXhr} from '@angular/http';
import {provide, ExceptionHandler} from '@angular/core';

// Components
import {PortalComponent} from './portal.component';
// import {AppComponent} from './app.component';

// Services
import {AppService} from './services/app/app.service';
import {PageService} from './pages/page/page.service';
import {NoticiaService} from './pages/noticia/noticia.service';
import {UsuarioService} from './services/usuario/usuario.service';
import {CORSBrowserXHr} from './components/CORSBrowserXHr';
import {CustomExceptionHandler} from './components/custom-exception-handler';

import {enableProdMode} from '@angular/core';
enableProdMode();

// import {LocalStorageSubscriber} from './component/angular2-localstorage/LocalStorageEmitter';

var appPromise = bootstrap(PortalComponent, [
    ROUTER_PROVIDERS, 
    HTTP_PROVIDERS,
    provide(BrowserXhr, { useClass: CORSBrowserXHr }),
// provide(RequestOptions, { useClass: DfRequestOptions }),
    provide(ExceptionHandler, { useClass: CustomExceptionHandler }),
    AppService,
    PageService,
    NoticiaService,
    UsuarioService
]);

// LocalStorageSubscriber(appPromise);