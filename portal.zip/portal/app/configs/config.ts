export let USI_URL = "http://"+window.location.hostname+":3000/api/usi";
export let GSI_URL = "http://"+window.location.hostname+":3000/api/projeto";
export let GLOBAL_URL = "http://"+window.location.hostname+":3000/api/global";
export let API_URL = "http://"+window.location.hostname+":3000/api";