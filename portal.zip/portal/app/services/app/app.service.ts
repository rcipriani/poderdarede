import {Injectable} from '@angular/core';
import {Http, Headers, RequestOptions} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import {Observer} from 'rxjs/Observer';
import 'rxjs/add/operator/share';
import 'rxjs/add/operator/startWith';
import 'rxjs/add/operator/map';

import {App} from './app.class';
import {USI_URL} from '../../configs/config';

@Injectable()
export class AppService {

    private _dataStore: {
        apps: App[],
        app: App
    };

    apps$: Observable<App[]>;
    private _appsObserver: Observer<App[]>;

    app$: Observable<App>;
    private _appObserver: Observer<App>;
    
    private _baseUrl: string;
    private count: number = 0;

    constructor(private _http: Http) {

        this._baseUrl = USI_URL + '/app';

        this._dataStore = { apps: [], app: {
            'id': null,
            'titulo': "",
            'texto': "",
            'midia': "",
            'slug': "",
            'url': "",
            'telaCheia': false,
            'novaJanela': false
        } };

        this.apps$ = new Observable<App[]>(observer => this._appsObserver = observer)
            .startWith(this._dataStore.apps)
            .share();

        this.app$ = new Observable<App>(observer => this._appObserver = observer)
            .startWith(this._dataStore.app)
            .share();

    }

    loadApps() {
//        http://localhost.bb.com.br:3000/projetos?subview=true
        
        this._http.get(`${this._baseUrl}/findall/`).map(response => response.json()).subscribe(data => {
            this._dataStore.apps = data;
            this._appsObserver.next(this._dataStore.apps);
        }, error => console.log('Falha ao carregar Apps.'));
    }
/*
    findAppById(id: number) {
        
        // return an observable
        return this._http.get(`${this._baseUrl}/get/` + id)
            .map( (responseData) => {
                let data =  responseData.json();
                if (data) {
                    let result: App = new App(data.id, 
                                        data.titulo,
                                        data.texto,
                                        data.midia,
                                        data.link);;
                    return result;
                }
            });
        
    }

    createAppRandonComId(app: App) {
        // TODO falta criar a route /createRandom. *Esta aqui s� de exemplo
        this._http.post(`${this._baseUrl}/createRandom/` + app.id, null)
            .map(response => response.json()).subscribe(data => {
                this._dataStore.apps.push(data);
                this._appsObserver.next(this._dataStore.apps);
            }, error => console.log('Could not create todo.'));
    }

    createApp(app: App) {

        console.log("console.log(this._appsObserver); CREATE", this._appsObserver);

        let appJson = JSON.stringify(app);

        var headers = new Headers();
        headers.append('Content-Type', 'application/json');

        this._http.post(`${this._baseUrl}/create`, appJson, {
            headers: headers
        }).map(response => response.json()).subscribe(data => {
            this._dataStore.apps.push(data);
            this._appsObserver.next(this._dataStore.apps);
        }, error => console.log('Could not create todo.'));

    }

    updateApp(app: App) {

        
        let appJson = JSON.stringify(app);

        var headers = new Headers();
        headers.append('Content-Type', 'application/json');

        this._http.put(`${this._baseUrl}/update/${app.id}`, appJson, {
            headers: headers
        })
            .map(response => response.json()).subscribe(data => {
		console.log("Update Cahmada", data);

		// TODO Colocar aqui que se n�o fizer update tem que avisar o usuario

                this._dataStore.apps.forEach((app, i) => {
                    if (app.id === data.id) {
                        this._dataStore.apps[i] = data;
                    }
                });

                this._appsObserver.next(this._dataStore.apps);
            }, error => console.log('Could not update todo.'));
    }

    deleteApp(app: App) {
        this._http.get(`${this._baseUrl}/delete/` + app.id)
            .map(response => response.json()).subscribe(data => {
                this._dataStore.apps.forEach((t, index) => {
                    if (t.id === app.id) { this._dataStore.apps.splice(index, 1); }
                });
                this._appsObserver.next(this._dataStore.apps);
            }, error => console.log('Could not create todo.'));
    }
*/
    handleError(error) {
        console.error(error);
        return Observable.throw(error.json().error || 'Server error');
    }

}