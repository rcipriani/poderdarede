export class App {
    id: number;
    titulo: string;
    texto: string;
    midia: string;
    slug: string;
    url: string;
    telaCheia: boolean;
    novaJanela: boolean;

    constructor(
        id: number,
        titulo: string,
        texto: string,
        midia: string,
        slug: string,
        url: string,
        telaCheia: boolean,
        novaJanela: boolean
    ) {
        this.id = id;
        this.titulo = titulo;
        this.texto = texto;
        this.midia = midia;
        this.slug = slug;
        this.url = url;
        this.telaCheia = telaCheia;
        this.novaJanela = novaJanela;
    }
}
