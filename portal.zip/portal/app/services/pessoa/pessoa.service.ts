import {Injectable} from '@angular/core';
import {Http, Headers, RequestOptions, URLSearchParams} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import {Observer} from 'rxjs/Observer';
import 'rxjs/add/operator/share';
import 'rxjs/add/operator/startWith';
import 'rxjs/add/operator/map';

import {Pessoa} from './pessoa.class';
import {USI_URL, GLOBAL_URL} from '../../configs/config';

@Injectable()
export class PessoaService {

    private _dataStore: {
        pessoas: Pessoa[],
        pessoaDetalhe: any[]
    };

    pessoas$: Observable<Pessoa[]>;
    private _pessoasObserver: Observer<Pessoa[]>;

    pessoaDetalhe$: Observable<any[]>;
    private _pessoaDetalheObserver: Observer<any[]>;

//    private _baseUrl: string;
//    private count: number = 0;

    constructor(private _http: Http) {

//        this._baseUrl = USI_URL + '/pessoa';

        this._dataStore = { pessoas: [] = [], pessoaDetalhe: [] = []};

        this.pessoas$ = new Observable<Pessoa[]>(observer => this._pessoasObserver = observer)
            .startWith(this._dataStore.pessoas)
            .share();

        this.pessoaDetalhe$ = new Observable<any[]>(observer => this._pessoaDetalheObserver = observer)
            .startWith(this._dataStore.pessoaDetalhe)
            .share();

    }

    loadPessoas(termoBusca: string) {
       
        //http://localhost.bb.com.br:3000/api/pessoa/pessoa/busca/valor?attributes=id&attributes=programa_id&attributes=nome&attributes=descricao&limit=20&offset=0&valor=a
        
        let query = "?";
        query += "attributes=id";
        query += "&attributes=nome";
        query += "&attributes=nomeExibicao";
        query += "&attributes=chave";
        query += "&attributes=prefixo";
        query += "&attributes=telefone";
        query += "&attributes=celular";
        query += "&attributes=email";
        
        query += "&limit=20";
        query += "&offset=0";
        query += "&order=NM_USU&order=ASC";
        
        this._http.get(`${GLOBAL_URL}/usuario/busca/valor${query}&valor=${termoBusca}`).map(response => response.json()).subscribe(data => {
                     
            this._dataStore.pessoas = data;
            this._pessoasObserver.next(this._dataStore.pessoas);
                     
        }, error => console.log('Falha ao carregar Pessoas.'));
    }

    loadDetalhePessoa(chave: string) {
        this._dataStore.pessoaDetalhe[chave] = {eps: true}  
        this._pessoaDetalheObserver.next(this._dataStore.pessoaDetalhe);   
    }
    
    handleError(error) {
        console.error(error);
        return Observable.throw(error.json().error || 'Server error');
    }

}