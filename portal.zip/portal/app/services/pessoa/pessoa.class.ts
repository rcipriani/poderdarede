export class Pessoa {
    id: string;
    prefixo: string;
    sb: number;
    matricula: number;
    nome: string;
    chave: string;
    nomeExibicao: string;
    comissao: number;
    ip: string;
    interno: boolean;
    grupamento: number;
    instituicao: number;
    pilar: number;
    rf: number;
    prefixoSuper: number;
    prefixoRegional: number;
    tipoDependencia: number;
    uf: string;
    imagem: string;
    ultimaVisita: string; //TODO date?
    uor_id: number;
    celular: string;
    telefone: string;
    telefoneResidencial: string;
    email: string;

    constructor(
        id: string,
        prefixo: string,
        sb: number,
        matricula: number,
        nome: string,
        chave: string,
        nomeExibicao: string,
        comissao: number,
        ip: string,
        interno: boolean,
        grupamento: number,
        instituicao: number,
        pilar: number,
        rf: number,
        prefixoSuper: number,
        prefixoRegional: number,
        tipoDependencia: number,
        uf: string,
        imagem: string,
        ultimaVisita: string,
        uor_id: number,
        celular: string,
        telefone: string,
        telefoneResidencial: string,
        email: string
    ) {
        this.id = id;
        this.prefixo = prefixo;
        this.sb = sb;
        this.matricula = matricula;
        this.nome = nome;
        this.chave = chave;
        this.nomeExibicao = nomeExibicao;
        this.comissao = comissao;
        this.comissao = comissao;
        this.ip = ip;
        this.interno = interno;
        this.grupamento = grupamento;
        this.instituicao = instituicao;
        this.pilar = pilar;
        this.rf = rf;
        this.prefixoSuper = prefixoSuper;
        this.prefixoRegional = prefixoRegional;
        this.tipoDependencia = tipoDependencia;
        this.uf = uf;
        this.imagem = imagem;
        this.ultimaVisita = ultimaVisita;
        this.uor_id = uor_id;
        this.celular = celular;
        this.telefone = telefone;
        this.telefoneResidencial = telefoneResidencial;
        this.email = email;
    }
}