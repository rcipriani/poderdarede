export class Usuario {
    id: number;
    chave: string;
    matricula: number;
    comissao: string;
    nome: string;
    nomeExibicao: string;
    celular: string;
    prefixo: string;
    uor_id: number;

    constructor(
        id: number,
        chave: string,
        matricula: number,
        comissao: string,
        nome: string,
        nomeExibicao: string,
        celular: string,
        prefixo: string,
        uor_id: number
    ) {
        this.id = id;
        this.comissao = comissao;
        this.chave = chave;
        this.matricula = matricula;
        this.nome = nome;
        this.nomeExibicao = nomeExibicao;
        this.celular = celular;
        this.prefixo = prefixo;
        this.uor_id = uor_id;
    }
}
