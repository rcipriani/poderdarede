import {Injectable} from '@angular/core';
import {Http, Headers, RequestOptions, URLSearchParams} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import {Observer} from 'rxjs/Observer';
import 'rxjs/add/operator/share';
import 'rxjs/add/operator/startWith';
import 'rxjs/add/operator/map';

import {Usuario} from './usuario.class';
import {API_URL, USI_URL} from '../../configs/config';

@Injectable()
export class UsuarioService {

    private _dataStore: {
        usuario: Usuario,
        preferencias: any
    };

    usuario$: Observable<Usuario>;
    private _usuarioObserver: Observer<Usuario>;

    preferencias$: Observable<any>;
    private _preferenciasObserver: Observer<any>;

    private _baseUrl: string;
    private _baseUsiUrl: string;

    constructor(private _http: Http) {

        this._baseUrl = API_URL + '/portal/sessao';
        this._baseUsiUrl = USI_URL;

        this._dataStore = {
            usuario: new Usuario(null, null, null, null, null, null, null, null, null),
            preferencias: {filtros: {}, apps: []}
        };

        this.usuario$ = new Observable<Usuario>(observer => this._usuarioObserver = observer)
            .startWith(this._dataStore.usuario)
            .share();

        this.preferencias$ = new Observable<any>(observer => this._preferenciasObserver = observer)
            .startWith(this._dataStore.preferencias)
            .share();

    }

    //http://localhost.bb.com.br:3000/api/usi/usuario/preffiltro/f8711939

    loadUsuarioLogado() {

        this._http.get(`${this._baseUrl}/usuario/`).map(response => response.json()).subscribe(data => {

            this._dataStore.usuario = data;
            this._usuarioObserver.next(this._dataStore.usuario);
            
        });

    }
    
    loadPreferencias() {
         this._http.get(`${this._baseUsiUrl}/usuario/preferencias/`).map(response => response.json()).subscribe(preferencias => {

                this._dataStore.preferencias = preferencias;
                this._preferenciasObserver.next(this._dataStore.preferencias);

            }, error => console.log('Falha ao carregar Usuario.'));
    }

    favoritarDesfavoritar(appId: number) {

        this._http.get(`${this._baseUsiUrl}/usuario/appsave/toggle/${appId}`).map(response => response.json()).subscribe(isFavoritado => {

            if (this._dataStore.preferencias != null
                && this._dataStore.preferencias.apps != null) {

                let index = this._dataStore.preferencias.apps.indexOf(appId);
                if (isFavoritado) {

                    if (index < 0) {
                        this._dataStore.preferencias.apps.push(appId);
                    }

                } else {

                    if (index => 0) {
                        this._dataStore.preferencias.apps.splice(index, 1);
                    }

                }
                
            }
            this._preferenciasObserver.next(this._dataStore.preferencias);

        }, error => console.log('Falha ao favoritar.'));

    }

    logout() {

        this._http.get(`${this._baseUrl}/logoff?p=/`).map(response => response.json()).subscribe(data => {

            console.log("data logoff", data);

        }, error => console.log('Falha ao efetuar logoff.'));

    }

    handleError(error) {
        console.error(error);
        return Observable.throw(error.json().error || 'Server error');
    }

}
