import {Injectable} from '@angular/core';
import {Http, Headers, RequestOptions, URLSearchParams} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import {Observer} from 'rxjs/Observer';
import 'rxjs/add/operator/share';
import 'rxjs/add/operator/startWith';
import 'rxjs/add/operator/map';

import {Projeto} from './projeto.class';
import {USI_URL, GSI_URL} from '../../configs/config';

@Injectable()
export class ProjetoService {

    private _dataStore: {
        projetos: Projeto[]
    };

    projetos$: Observable<Projeto[]>;
    private _projetosObserver: Observer<Projeto[]>;

//    private _baseUrl: string;
//    private count: number = 0;

    constructor(private _http: Http) {

//        this._baseUrl = USI_URL + '/projeto';

        this._dataStore = { projetos: []};

        this.projetos$ = new Observable<Projeto[]>(observer => this._projetosObserver = observer)
            .startWith(this._dataStore.projetos)
            .share();

    }

    //http://localhost.bb.com.br:3000/api/projeto/projeto/busca/valor?attributes=id&attributes=programa_id&attributes=nome&attributes=descricao&attributes=percentualExecutado&limit=20&offset=0&valor=monteiro
    
    loadProjetos(termoBusca) {
       
        //http://localhost.bb.com.br:3000/api/projeto/projeto/busca/valor?attributes=id&attributes=programa_id&attributes=nome&attributes=descricao&limit=20&offset=0&valor=a
        
        let query = "?";
        query += "attributes=id";
        query += "&attributes=programa_id";
        query += "&attributes=nome";
        query += "&attributes=descricao";
        query += "&attributes=percentualExecutado";
        
        query += "&limit=20";
        query += "&offset=0";
//        query += "&order=NM_USU&order=ASC";
        
        this._http.get(`${GSI_URL}/projeto/busca/valor${query}&valor=${termoBusca}`).map(response => response.json()).subscribe(data => {
                     
            this._dataStore.projetos = data;
            this._projetosObserver.next(this._dataStore.projetos);
                     
        }, error => console.log('Falha ao carregar Projetos.'));
    }
    
    handleError(error) {
        console.error(error);
        return Observable.throw(error.json().error || 'Server error');
    }

}