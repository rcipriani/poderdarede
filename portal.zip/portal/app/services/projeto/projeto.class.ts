export class Projeto {
    id: number;
    nome: string;
    descricao: string;
    programa: {};

    constructor(
        id: number,
        nome: string,
        descricao: string,
        programa: {}
    ) {
        this.id = id;
        this.nome = nome;
        this.descricao = descricao;
        this.programa = programa;
    }
}