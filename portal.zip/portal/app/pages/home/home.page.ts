import {Component, OnInit, Input, Output, ViewChild} from '@angular/core';
import { Router,
    RouteConfig,
    ROUTER_DIRECTIVES,
    RouteParams } from '@angular/router-deprecated';
import {Observable} from 'rxjs/Rx';

import {Page} from '../page/page.class';
import {PageService} from '../page/page.service';

import {Usuario} from '../../services/usuario/usuario.class';
import {UsuarioService} from '../../services/usuario/usuario.service';

import {UsiBgSlideDirective} from '../../directives/usi-bg-slide.directive';
import {UsiGoDirective} from '../../directives/usi-go.directive';

import {SearchPipe} from '../../pipes/busca-search.pipe';
import {AppListComponent} from '../../components/app/app-list.component';


@Component({
    templateUrl: './app/pages/home/home.template.html',
    styleUrls: ['./app/pages/home/home.style.css'],
    pipes: [SearchPipe],
    directives: [ROUTER_DIRECTIVES, UsiBgSlideDirective, UsiGoDirective, AppListComponent]
})
export class HomePage implements OnInit {

    public strBusca = "";
    public paramBusca: string = "";
    private delay: number = 300;
    @ViewChild('inputSearch') inputSearchElement: any;
    public value: string = "";

    public pages: Observable<Page[]>;
    public apps: Observable<App[]>;
    public usuarioAtivo: Usuario;
    public maisBuscados: string[] = [];

    constructor(
        private _pageService: PageService,
        private _usuarioService: UsuarioService,
        private _router: Router) {

    }

    ngOnInit() {

        // Informações do usuário
        this._usuarioService.usuario$.subscribe(data => {
            this.usuarioAtivo = data;
        });
        this._usuarioService.loadUsuarioLogado();

        // Informações sobre as páginas
        this.pages = this._pageService.pages$;
        this._pageService.loadPages(true);
        
        // TODO Implementar mais buscados
        this.maisBuscados = ["Gestão", "GSI PRO", "Administrativa", "ARH", "Funcionários"];

    }

    ngAfterViewInit() {

        const eventStream = Observable.fromEvent(this.inputSearchElement.nativeElement, 'keyup')
            .map(() => this.paramBusca)
            .debounceTime(this.delay)
            .distinctUntilChanged();

        let me = this;
        eventStream.subscribe(function(input) {
            me.strBusca = input;
        });

        //TODO corrigir isto
        let carousel: any = $('.carousel');
        carousel.carousel({
            interval: 5000
            //changes the speed
        })

    }

    buscar(paramBusca) {
        if (paramBusca == null) {
            paramBusca = "";
        }
        this._router.navigate(['Busca', { s: paramBusca }]);
    }

    abrirUrl(url) {
        window.open(url, '_blank');
    }
}
