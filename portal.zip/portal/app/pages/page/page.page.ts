import {Component, OnInit} from '@angular/core';
import {RouteParams, Router, ROUTER_DIRECTIVES} from '@angular/router-deprecated';
import {Observable} from 'rxjs/Observable';

import {App} from '../../services/app/app.class';
import {AppService} from '../../services/app/app.service';
import {AppComponent} from '../../components/app/app.component';

import {Page} from './page.class';
import {PageService} from './page.service';

import {Usuario} from '../../services/usuario/usuario.class';
import {UsuarioService} from '../../services/usuario/usuario.service';

import {CardMiniComponent} from '../../components/card-mini.component';
import {UsiGoDirective} from '../../directives/usi-go.directive';

@Component({
    templateUrl: './app/pages/page/page.template.html',
	styleUrls: ['./app/pages/page/page.style.css'],
    directives: [ROUTER_DIRECTIVES, AppComponent, UsiGoDirective]
})

export class PagePage implements OnInit {

    public apps : Observable<App[]>;
    public pages : Observable<Page[]>;
	public page: Page;
    public subHeaderCover: string = "";
    public usuarioPreferenciaApps: number[];
		
	constructor( 
        private _appService: AppService,
        private _pageService: PageService,
        private _usuarioService: UsuarioService,
		private _router: Router,
		private _routeParams: RouteParams) {

    }

    ngOnInit() {
        
        // Preferências do usuário
        this._usuarioService.preferencias$.subscribe(data => {
            if (data != null && data.apps != null) {
                this.usuarioPreferenciaApps = data.apps;
            }
        });
        this._usuarioService.loadPreferencias();
	
		if (this._routeParams.get('slug') != null) {
		
            let slug = this._routeParams.get('slug');
			
			this.page = {
				'id': null,
				'slug': "",
				'titulo': "",
				'texto': "",
				'html': "",
                'midia': "blank.png",
				apps: []
			}
			
			this._pageService.findPageBySlug(slug, true).subscribe(res => this.page = res);
			
        }
		
    }

    public abrirUrl(url) {
        window.open(url, '_blank');
    }
		
}
