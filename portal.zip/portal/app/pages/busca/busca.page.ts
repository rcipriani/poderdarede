import {Component, OnInit, Input, Output, ViewChild} from '@angular/core';
import {CORE_DIRECTIVES, Location} from '@angular/common';
import {Observable} from 'rxjs/Rx';
import {Router,
        RouteConfig,
        ROUTER_DIRECTIVES,
        RouteParams} from '@angular/router-deprecated';

import {Page} from '../page/page.class';
import {PageService} from '../page/page.service';

import {App} from '../../services/app/app.class';
import {AppService} from '../../services/app/app.service';
import {AppComponent} from '../../components/app/app.component';

import {Usuario} from '../../services/usuario/usuario.class';
import {UsuarioService} from '../../services/usuario/usuario.service';

import {Projeto} from '../../services/projeto/projeto.class';
import {ProjetoService} from '../../services/projeto/projeto.service';

import {Pessoa} from '../../services/pessoa/pessoa.class';
import {PessoaService} from '../../services/pessoa/pessoa.service';

import {SearchPipe} from '../../pipes/busca-search.pipe';

import {CardMiniComponent} from '../../components/card-mini.component';
import {UsiGoDirective} from '../../directives/usi-go.directive';

@Component({
    selector: 'busca-page',
    templateUrl: './app/pages/busca/busca.template.html',
    styleUrls: ['./app/pages/busca/busca.style.css'],
    pipes: [SearchPipe],
    directives: [ROUTER_DIRECTIVES, CardMiniComponent, UsiGoDirective, AppComponent],
    providers: [ProjetoService, PessoaService]
})
export class BuscaPage implements OnInit {

    private $ : any;
    private JQuery : any;
    
    @Input() public strBusca = "";
    @Input() private delay: number = 300;

    @ViewChild('inputSearch') inputSearchElement: any;
    public value: string = "";
    public maisBuscados: any[] = [];
    public filtros: boolean[] = [];

    public pages: Observable<Page[]>;
    public apps: Observable<App[]>;
    public projetos: Observable<Projeto[]>;
    public pessoas: Observable<Pessoa[]>;
    public pessoaDetalhe: Observable<any[]>;

    constructor(
        private _pageService: PageService,
        private _usuarioService: UsuarioService,
        private _appService: AppService,
        private _projetoService: ProjetoService,
        private _pessoaService: PessoaService,
        private _location: Location,
        private _routeParams: RouteParams) {
    }

    ngOnInit() {
        let searchWords = this._routeParams.get('s');

        if (searchWords) {
            this.strBusca = searchWords;
            this.value = searchWords;
        }

        this.pages = this._pageService.pages$;
        this._pageService.loadPages(true);

        this.apps = this._appService.apps$;
        this._appService.loadApps();

        this.projetos = this._projetoService.projetos$;
        this.pessoas = this._pessoaService.pessoas$;
        this.pessoaDetalhe = this._pessoaService.pessoaDetalhe$;

        this.maisBuscados = ["Gestão", "GSI PRO", "Administrativa", "ARH", "Funcionários"];
        this.filtros["filtroGsiPro"] = true;
        this.filtros["filtroPage"] = true;
        this.filtros["filtroApp"] = true;
        this.filtros["filtroPessoa"] = true;

    }

    ngAfterViewInit() {

        const eventStream = Observable.fromEvent(this.inputSearchElement.nativeElement, 'keyup')
            .map(() => this.value)
            .debounceTime(this.delay)
            .distinctUntilChanged();

        let me = this;
        eventStream.subscribe(function(input) {
            
            me._buscar(input);

        });
        this._buscar(this.strBusca);

        // Controla a mudança dos switch de filtro da tela
//        $(".checkbox-switch").bootstrapSwitch();
        let filtros = this.filtros;
        $(".checkbox-switch").on('switchChange.bootstrapSwitch', function(event, state) {
            filtros[this.name] = state;
        }); 

        //Foco no input de busca ao abrir a página
        this.inputSearchElement.nativeElement.focus();

    }
    
    // MÉDOTOS PÚBLICOS
    public loadPessoaDetalhe(chave: string){
        this._pessoaService.loadDetalhePessoa(chave);
    }

    public limparBusca() {
        this.value = "";
        this._buscar(this.value);
    }

    public voltar() {
        this._location.back();
    }

    public abrirUrl(url) {
        window.open(url, '_blank');
    }

    //MÉTODOS PRIVADOS
    private _buscar(value) {
        this.strBusca = value;
        this._projetoService.loadProjetos(value);
        this._pessoaService.loadPessoas(value);
    }

}
