import {Injectable} from '@angular/core';
import {Http, Headers, RequestOptions, URLSearchParams} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import {Observer} from 'rxjs/Observer';
import 'rxjs/add/operator/share';
import 'rxjs/add/operator/startWith';
import 'rxjs/add/operator/map';

import {Projeto} from '../../services/projeto/projeto.class';
import {USI_URL, GSI_URL} from '../../configs/config';

@Injectable()
export class BuscaService {

    private _dataStore: {
        projetos: Projeto[]
    };

    projetos$: Observable<Projeto[]>;
    private _projetosObserver: Observer<Projeto[]>;

//    private _baseUrl: string;
//    private count: number = 0;

    constructor(private _http: Http) {

//        this._baseUrl = USI_URL + '/projeto';

        this._dataStore = { projetos: []};

        this.projetos$ = new Observable<Projeto[]>(observer => this._projetosObserver = observer).startWith(this._dataStore.projetos).share();

    }

//    loadProjetos(termoBusca) {
//       
//        //http://localhost.bb.com.br:3000/api/projeto/projeto/busca/valor?attributes=id&attributes=programa_id&attributes=nome&attributes=descricao&limit=20&offset=0&valor=a
//        
//        let params: URLSearchParams = new URLSearchParams();
//        if (typeof _includeApps !== "undefined") {
//        
//            params = new URLSearchParams();
//            params.set('includeapps', _includeApps);
//            
//        }
//        
//        this._http.get(`${GSI_URL}/projeto/busca/valor?attributes=id&attributes=programa_id&attributes=nome&attributes=descricao&limit=20&offset=0&valor=${termoBusca}`, {
//                   search: params
//                 }).map(response => response.json()).subscribe(data => {
//                     
//            this._dataStore.projetos = data;
//            this._projetosObserver.next(this._dataStore.projetos);
//                     
//        }, error => console.log('Falha ao carregar Projetos.'));
//    }
//    
    handleError(error) {
        console.error(error);
        return Observable.throw(error.json().error || 'Server error');
    }

}