import {Component, OnInit} from '@angular/core';
import {RouteParams, Router, ROUTER_DIRECTIVES} from '@angular/router-deprecated';
import {Observable} from 'rxjs/Observable';

import {Noticia} from './noticia.class';
import {NoticiaService} from './noticia.service';

import {UsiGoDirective} from '../../directives/usi-go.directive';

@Component({
    templateUrl: './app/pages/noticia/noticia.template.html',
	styleUrls: ['./app/pages/noticia/noticia.style.css'],
    directives: [ROUTER_DIRECTIVES, UsiGoDirective]
})

export class NoticiaPage implements OnInit {

    public noticias : Observable<Noticia[]>;
	public noticia: Noticia;
		
	constructor( 
        private _noticiaService: NoticiaService,
		private _router: Router,
		private _routeParams: RouteParams) {

    }

    ngOnInit() {
        
		if (this._routeParams.get('slug') != null) {
		
            let slug = this._routeParams.get('slug');
			
			this.noticia = {
				'id': null,
				'slug': "",
				'titulo': "",
				'resumo': "",
                'midia': "blank.png",
				'html': "",
				'categoria': ""
			}
			
			this._noticiaService.findBySlug(slug, true).subscribe(res => this.noticia = res);
			
        }
		
    }

    public abrirUrl(url) {
        window.open(url, '_blank');
    }
		
}
