import {Injectable} from '@angular/core';
import {Http, Headers, RequestOptions, URLSearchParams} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import {Observer} from 'rxjs/Observer';
import 'rxjs/add/operator/share';
import 'rxjs/add/operator/startWith';
import 'rxjs/add/operator/map';

import {Noticia} from './noticia.class';
import {USI_URL} from '../../configs/config';

@Injectable()
export class NoticiaService {

    private _dataStore: {
        noticias: Noticia[],
        noticia: Noticia
    };

    noticias$: Observable<Noticia[]>;
    private _noticiasObserver: Observer<Noticia[]>;

    noticia$: Observable<Noticia>;
    private _noticiaObserver: Observer<Noticia>;

    private _baseUrl: string;
    private count: number = 0;

    constructor(private _http: Http) {

        this._baseUrl = USI_URL + '/noticia';

        this._dataStore = { noticias: [], noticia: {
            'id': null,
            'slug': "",
            'titulo': "",
            'resumo': "",
            'midia': "",
            'html': "",
            'categoria': ""
        } };

        this.noticias$ = new Observable<Noticia[]>(observer => this._noticiasObserver = observer)
            .startWith(this._dataStore.noticias)
            .share();

        this.noticia$ = new Observable<Noticia>(observer => this._noticiaObserver = observer)
            .startWith(this._dataStore.noticia)
            .share();

    }

    loadNoticias(_includeApps: boolean) {
        
        this._http.get(`${this._baseUrl}/findAll`).map(response => response.json()).subscribe(data => {
                     
            this._dataStore.noticias = data;
            this._noticiasObserver.next(this._dataStore.noticias);
                     
        }, error => console.log('Falha ao carregar Noticias.'));
    }
    
    findBySlug(_slug: string, _includeApps: boolean) {
        
        return this._http.get(`${this._baseUrl}/slug/` + _slug).map( (responseData) => {
            
                let data =  responseData.json();
                if (data) {
                    let result: Noticia = new Noticia(data.id, 
                                        data.slug,
                                        data.titulo,
                                        data.resumo,
                                        data.midia,
                                        data.html,
                                        data.categoria);
                    return result;
                }
                
        });
        
    }

    handleError(error) {
        console.error(error);
        return Observable.throw(error.json().error || 'Server error');
    }

}
