export class Noticia {
    id: number;
	slug: string;
    titulo: string;
    resumo: string;
    midia: string;
    html: string;
    categoria: string;

    constructor(
        id: number,
        slug: string,
        titulo: string,
        resumo: string,
        midia: string,
        html: string,
		categoria: string
    ){
        this.id = id;
        this.slug = slug;
        this.titulo = titulo;
        this.resumo = resumo;
        this.midia = midia;
        this.html = html;
		this.categoria = categoria;
    }
}