import {Component, OnInit, ViewChild} from "@angular/core";
import {Observable} from 'rxjs/Observable';
import {RouteParams, Router} from '@angular/router-deprecated';

import {App} from '../../services/app/app.class';
import {AppService} from '../../services/app/app.service';

@Component({
    templateUrl: './app/components/external-url-page/external-url-page.component.html',
    styleUrls: ['./app/components/external-url-page/external-url-page.style.css']
})

// TODO este component não está isolado, ele não deve importar App e AppService
    
export class ExternalUrlPageComponent implements OnInit {

    public destino: string = "";
    public apps: Observable<App[]>;
    public app: App;
    private slug : string = "";
    
    @ViewChild('pageContainerObject') pageContainerObject: any;
    
    constructor( 
        private _routeParams: RouteParams,
        private _appService: AppService) {

    }

    ngOnInit() {
        
        let slug = "";
        
         if (this._routeParams.get('slug') != null) {
            this.slug = this._routeParams.get('slug');
            slug = this._routeParams.get('slug');
        }
        
        this.apps = this._appService.apps$;
        
//        this._appService.apps$.subscribe(updatedApps => this.app = updatedApps.filter(function (app){
//            if(app.slug == slug){
//                
//                // TODO Somente para testes
//                if(window.location.hostname == "localhost.bb.com.br"){
//                    app.url = app.url.replace("infra.servicos.bb.com.br/", "localhost.bb.com.br:3000/");
//                    app.url = app.url.replace("infra.servicos.bb.com.br:3000/", "localhost.bb.com.br:3000/");
//                }
//                return app;
//            }
//        })[0]);
        
        this._appService.loadApps();
        
//        console.log(this._appService.getHtml());
        
    }

    private wait : boolean = false;
    
    ngAfterViewInit() {
    
        this.redimenciona();
        let me = this;
        $(window).resize(function() {
            console.log("vaiiii");
            if(!this.wait){
                me.redimenciona();
                me.wait = true;
            }
        });
                
    }

    redimenciona(){
        
        let bodyHeight = $("body").outerHeight();
        let footerHeight = $("footer").outerHeight();
        let navbar_primaryHeight = $(".navbar_primary").outerHeight();
        let navbar_secondaryHeight = $(".navbar_secondary").outerHeight();
        
        console.log(bodyHeight + " - " + footerHeight + " - " + navbar_primaryHeight + " - " + navbar_secondaryHeight);
        
        let temp = 105;
        
        $("#pageContainerObject").css('height', bodyHeight-(footerHeight+navbar_primaryHeight+navbar_secondaryHeight+temp));
        this.wait = false;
        
    }
}
