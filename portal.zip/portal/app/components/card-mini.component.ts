import {Component, Input, Output, ElementRef, EventEmitter} from '@angular/core';
import {CORE_DIRECTIVES} from '@angular/common';
import {Observable} from 'rxjs/Rx';

@Component({
    selector: 'card-mini',
    template: `
            <div class="media panel clicavel {{tema}}">
                <div *ngIf="midia != ''" class="panel-heading" [ngStyle]="{'background-image': 'url(' + midia + ')'}" style="background-size: cover; background-position: center;">
                    <span class="fa-stack fa-5x"></span>
                </div>
                <div class="panel-body" [ngStyle]="{'height': altura}">
                    <h4 *ngIf="titulo != ''">{{titulo}}</h4>
                    <p *ngIf="texto != ''">{{texto}}</p>
                </div>
            </div>
    `,
    styles:[`

        h4 {
            margin-bottom: 0px;
            margin-top: 0px;
        }

        .panel .panel-heading {
            border-bottom: 1px solid #f1f1f1;
        }

        .panel .panel-body {
            padding: 10px;
            overflow-y: auto;
        }

        .panel:hover a {
            color: #fff;
        }

        .clicavel {
            cursor: pointer;
        }

        .claro:hover {
            background-color: #1A5E9B;
            color: #fff;
        }
        
        .claro:hover h4 {
            color: #fff;
        }
        
        .azul_escuro a, .azul_claro a {
            color: #fff;
        }
        
        .azul_escuro {
            cursor: pointer;
            background-color: #003658;
        }
        
        .azul_escuro:hover {
            background-color: #1A5E9B;
        }
        
        .azul_claro {
            cursor: pointer;
            background-color: #1A5E9B;
        }
        
        .azul_claro:hover {
            background-color: #003658;
        }
    `]
})

export class CardMiniComponent {
    @Input() titulo: string = "";
    @Input() texto: string = "";
    @Input() midia: string = "";
    @Input() tema: string = "claro";
    @Input() altura: string = "140px";
//    @Output() value: EventEmitter = new EventEmitter();

//    public inputValue: string;

    constructor(private elementRef: ElementRef) {

//        const eventStream = Observable.fromEvent(elementRef.nativeElement, 'keyup')
//            .map(() => this.inputValue)
//            .debounceTime(this.delay)
//            .distinctUntilChanged();
//
//        eventStream.subscribe(input => this.value.emit(input));
    }
}
