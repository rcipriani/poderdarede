import {Injectable, ExceptionHandler} from '@angular/core';
import {HTTP_PROVIDERS} from '@angular/http';

class _ArrayLogger {
    res = [];
    log(s: any): void { this.res.push(s); }
    logError(s: any): void { this.res.push(s); }
    logGroup(s: any): void { this.res.push(s); }
    logGroupEnd() {
        this.res.forEach(error => {
            console.error(error);
        })
    };
}

@Injectable()
export class CustomExceptionHandler extends ExceptionHandler {
    constructor() {
        super(new _ArrayLogger(), true);
    }

    call(exception: any, stackTrace: any, reason: string): void {

//        console.log("exception", exception);
//        console.log("stackTrace", stackTrace);
//        console.log("reason", reason);
        
        if (~[401, 403].indexOf(exception.status)) {
            window.location.href = 'https://login.intranet.bb.com.br/distAuth/UI/Login?goto='+window.location;
        } else {
            super.call(exception, stackTrace, reason);
        }
    }
}