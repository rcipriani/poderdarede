import {Component, Input, Output, ElementRef, EventEmitter} from '@angular/core';
import {CORE_DIRECTIVES} from '@angular/common';
import {Observable} from 'rxjs/Rx';

import {App} from '../../services/app/app.class';
import {UsuarioService} from '../../services/usuario/usuario.service';
import {UsiGoDirective} from '../../directives/usi-go.directive';

@Component({
    selector: 'app-component',
    directives: [UsiGoDirective],
    templateUrl: './app/components/app/app.template.html',
    styleUrls: ['./app/components/app/app.style.css']
})

export class AppComponent {
    @Input() app: App;
    @Input() favoritos: number[];
    @Input() tema: string = "claro";
    @Input() altura: string = "140px";

    constructor(private elementRef: ElementRef, private _usuarioService: UsuarioService) {
        
    }
    
    favoritarDesfavoritar(app : App){
        this._usuarioService.favoritarDesfavoritar(app.id);
    }

    isFavorito(appId){
        if(this.favoritos && this.favoritos.length > 0)
            return this.favoritos.indexOf(appId) >= 0;   
        else
            return false; 
    }
}
