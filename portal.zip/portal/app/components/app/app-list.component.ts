import {Component, Input, Output, ElementRef, EventEmitter} from '@angular/core';
import {CORE_DIRECTIVES} from '@angular/common';
import {Observable} from 'rxjs/Rx';

import {App} from '../../services/app/app.class';
import {AppComponent} from './app.component';
import {AppService} from '../../services/app/app.service';

import {Usuario} from '../../services/usuario/usuario.class';
import {UsuarioService} from '../../services/usuario/usuario.service';

import {SearchPipe} from '../../pipes/busca-search.pipe';

@Component({
    selector: 'app-list-component',
    directives: [],
    pipes: [SearchPipe],
    templateUrl: './app/components/app/app-list.template.html',
    styleUrls: ['./app/components/app/app-list.style.css']
})

export class AppListComponent {
    
    apps: App[];
    @Input() favoritos: number[];
    @Input() tema: string = "claro";
    @Input() altura: string = "140px";
    
    public filtroApps: number[] = null;
    public filtroAppAtivo: string = "favoritos";
    public usuarioPreferenciaApps: number[];

    constructor(private elementRef: ElementRef,
                private _usuarioService: UsuarioService,
                private _appService: AppService
               ) {
        
    }

    ngOnInit() {

        // Preferências do usuário
        this._usuarioService.preferencias$.subscribe(data => {
            if (data != null && data.apps != null) {
                this.usuarioPreferenciaApps = data.apps;
            }
            // Inicializando na primeira abertura
            if (this.filtroAppAtivo == "favoritos") {
                this.filtroApps = this.usuarioPreferenciaApps;
            }
        });
        this._usuarioService.loadPreferencias();

        // Informações sobre os apps 
        this.apps = this._appService.apps$;
        this._appService.loadApps();

    }
    
    isFavorito(appId){
        if(this.favoritos && this.favoritos.length > 0)
            return this.favoritos.indexOf(appId) >= 0;   
        else
            return false; 
    }
    
    filtroAppFavoritos() {
        this.filtroAppAtivo = "favoritos";
        if (this.usuarioPreferenciaApps != null) {
            this.filtroApps = this.usuarioPreferenciaApps;
        }
    }

    filtroAppTodos() {
        this.filtroAppAtivo = "todos";
        this.filtroApps = [];
    }

    isFiltroTodos() {
        return this.filtroAppAtivo != "favoritos";
    }
}
